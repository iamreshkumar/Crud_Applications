package com.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileApplicationTests {

	@Test
	void contextLoads() {
	}

}
