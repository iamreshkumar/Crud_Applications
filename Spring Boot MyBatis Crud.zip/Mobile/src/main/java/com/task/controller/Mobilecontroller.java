package com.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.task.entity.Mobile;
import com.task.service.Mobileservice;

@RestController

@RequestMapping("/Mobile")
public class Mobilecontroller {
	@Autowired
	private Mobileservice mobileService;
	
	@PostMapping("/add/mobile")
	public String add(@RequestBody Mobile mb) {
		
		
    return mobileService.add(mb);
	}
	/*
	 * public ResponseEntity<?> insert(@RequestBody Mobile mb){
	 * mobileService.insert(); }
	 */
	
	@GetMapping("/get/{brand}")
	public String getBybrand(@PathVariable(name ="brand") String brand) {
		return mobileService.getBrand(brand);

	}
	 
	@PostMapping("/delete")
	public ResponseEntity<?> delete(@RequestBody Mobile mb) {
		return mobileService.delete(mb);
	}
	/*
	 * @GetMapping("/get/{brand}") public ResponseEntity<List<Mobile>>
	 * getBybrand(@PathVariable(name="brand") String brand){ return
	 * mobileService.getBrand(brand);
	 * 
	 * }
	 */
	/*
	 * @GetMapping("/get/all") public List<Mobile> getAll(){
	 * 
	 * //List<Mobile> all=mobileService.getAll(mb); return mobileService.getAll();
	 * 
	 * }
	 */
	@PostMapping("/getAll/status")
	public List<Mobile> getAllSt(String status){
		return mobileService.getAllSt(status);

	}

}
