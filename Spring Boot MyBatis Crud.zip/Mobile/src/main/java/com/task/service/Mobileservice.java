package com.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.task.entity.Mobile;
import com.task.mapper.Mobilemapper;

@Service
public class Mobileservice {

	@Autowired
	private Mobilemapper mobilemapper;

	public String add(Mobile mb) {
		System.out.println(mb);
		
		
		Mobile mbl = mobilemapper.getmb(mb.getModel());
	
		if (mbl == null) {
		

			int result=mobilemapper.add(mb);
         if(result>0)
         				{
        	// mbl.setStatus("active");
			return "details added successfully";
}
		} else {
			return "data already existed";
		}
		
		 return "details added successfully";
		 
	
	}

	
	public String getBrand(String brand) {

		Mobile mbc = mobilemapper.getBrand(brand);
		if(mbc!=null) {

		return "Data"+mbc;
		}
		else {
			return "error";	
		}
		

	}
	/*
	 * public List<Mobile> getAll(){
	 * 
	 * 
	 * return mobilemapper.getAll();
	 * 
	 * }
	 */

	public ResponseEntity<?> delete(Mobile mb) {
		
	Mobile mbl=mobilemapper.getmb(mb);
	
	if(mbl==null) {
		return ResponseEntity.ok().body("model not present");
	}
	//String finalresult=null;
	else {
		
		mobilemapper.delete(mb);
		
		
		return  ResponseEntity.ok().body("deleted");
	}
	
	
	
//	if(mbl==null) {
//	int deleteresult=mobilemapper.delete(mb);
//		if(deleteresult>0)
//		{
//			
//		
//	
//	return finalresult="deleted";
//		}
//		else
//		{
//			return finalresult="invalid";
//
//		}
//	}
//	else {
//		
//		return finalresult="invalid";
//	}
	}


	/*
	 * public ResponseEntity<Mobile> getAll(Mobile mb) { Mobile
	 * l=mobilemapper.getActive(mb); return ResponseEntity.ok().body(l);
	 *///}


	public List<Mobile> getAllSt(String status) {
		List<Mobile> m=mobilemapper.getActive(status);
		return m;
	}


}


