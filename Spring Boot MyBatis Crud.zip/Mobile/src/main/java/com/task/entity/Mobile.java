package com.task.entity;

public class Mobile {
	private String brand;
	private String model;
	private String ram;
	private String rom;
	private String cam;
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCam() {
		return cam;
	}
	public void setCam(String cam) {
		this.cam = cam;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	public String getRom() {
		return rom;
	}
	public void setRom(String rom) {
		this.rom = rom;
	}
	@Override
	public String toString() {
		return "Mobile [brand=" + brand + ", model=" + model + ", ram=" + ram + ", rom=" + rom + "]";
	}
	
}
