package com.task.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.http.ResponseEntity;

import com.task.entity.Mobile;
@Mapper
public interface Mobilemapper {
	
	public int add(Mobile mb);
	public  Mobile get(String model);
	public List<Mobile> getAllSt(String status);
	//public List<Mobile> getBybrand();
	//public Mobile getBrand(String brandName);
	//public List<Mobile> getBrand(Mobile brand);
	public Mobile getmb(String brand);
	public List<Mobile> getAll(String brand);
	public Mobile getBrand(String brand);
	
	
	public Mobile getmb(Mobile mb);
	
	public void delete(Mobile mb);
	public List<Mobile> getActive(String status);
	//public List<Mobile> getDeleted(String status);
	//public Mobile getActive(String status);
}
