package com.product.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.cloud.FirestoreClient;
import com.product.entity.Product;

@Service
public class ProductService {

	/**
	 * Firebase DB Collection Name
	 */
	private static final String Collection_Name = "products";

	/**
	 * <p>
	 * Save New Product
	 * </p>
	 * 
	 * @param product
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public String saveNewProduct(Product product) throws InterruptedException, ExecutionException {

		Firestore dbFireStore = FirestoreClient.getFirestore();

		ApiFuture<WriteResult> apiFutureWrite = dbFireStore.collection(Collection_Name)
				.document(product.getProductName()).set(product);

		return apiFutureWrite.get().getUpdateTime().toString();
	}

	public List<Product> getAllProductData() throws InterruptedException, ExecutionException {

		Firestore dbFireStore = FirestoreClient.getFirestore();

		Iterable<DocumentReference> documentReference = dbFireStore.collection(Collection_Name).listDocuments();
		Iterator<DocumentReference> iterator = documentReference.iterator();

		Product product;
		List<Product> productList = new ArrayList<>();

		while (iterator.hasNext()) {
			DocumentReference documentFuture = iterator.next();
			ApiFuture<DocumentSnapshot> future = documentFuture.get();
			DocumentSnapshot document = future.get();
			product = document.toObject(Product.class);
			productList.add(product);
		}
		return productList;
	}

	/**
	 * <p>
	 * Get One product
	 * </p>
	 * 
	 * @param productName
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public ResponseEntity<?> getProductData(String productName) throws InterruptedException, ExecutionException {

		Firestore dbFireStore = FirestoreClient.getFirestore();

		DocumentReference documentReference = dbFireStore.collection(Collection_Name).document(productName);

		ApiFuture<DocumentSnapshot> future = documentReference.get();

		DocumentSnapshot document = future.get();

		Product prod;

		if (document.exists()) {
			prod = document.toObject(Product.class);
			return ResponseEntity.ok(prod);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(productName + " product does not found");
		}
	}

	/**
	 * <p>
	 * Update product
	 * </p>
	 * 
	 * @param product
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public String updateProduct(Product product) throws InterruptedException, ExecutionException {

		Firestore dbFireStore = FirestoreClient.getFirestore();

		ApiFuture<WriteResult> apiFutureWrite = dbFireStore.collection(Collection_Name)
				.document(product.getProductName()).set(product);

		return apiFutureWrite.get().getUpdateTime().toString();
	}

	/**
	 * <p>
	 * Delete Product
	 * </p>
	 * 
	 * @param productName
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public String deleteProduct(String productName) throws InterruptedException, ExecutionException {

		Firestore dbFireStore = FirestoreClient.getFirestore();
		ApiFuture<WriteResult> apiFutureWrite = dbFireStore.collection(Collection_Name).document(productName).delete();

		// To-do Validations

		return productName + " : product deleted Sucessfully at time " + apiFutureWrite.get().getUpdateTime();
	}
}
