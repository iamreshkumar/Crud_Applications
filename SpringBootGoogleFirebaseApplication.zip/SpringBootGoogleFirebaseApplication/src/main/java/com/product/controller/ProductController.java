package com.product.controller;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.entity.Product;
import com.product.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping("/saveNewProduct")
	public ResponseEntity<?> saveNewProduct(@RequestBody Product product)
			throws InterruptedException, ExecutionException {
		String time = productService.saveNewProduct(product);
		return ResponseEntity.accepted().body("Product saved sucessfully at time :" + time);
	}

	@GetMapping("/getAllProduct")
	public List<Product> getAllProduct() throws InterruptedException, ExecutionException {
		return productService.getAllProductData();
	}

	@GetMapping("/getOneProduct/{productName}")
	public ResponseEntity<?> getOneProduct(@PathVariable String productName) throws InterruptedException, ExecutionException {
		return productService.getProductData(productName);
	}

	@PutMapping("/updateProduct")
	public ResponseEntity<?> updateProduct(@RequestBody Product product)
			throws InterruptedException, ExecutionException {
		String updatedTime = productService.updateProduct(product);
		return ResponseEntity.accepted().body("Your Product has been Updated at time:" + updatedTime);
	}

	@DeleteMapping("/deleteProduct/{productName}")
	public String DeleteProduct(@PathVariable String productName) throws InterruptedException, ExecutionException {
		return productService.deleteProduct(productName);
	}

}
