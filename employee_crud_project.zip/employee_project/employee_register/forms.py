from dataclasses import field, fields
from django import forms
from .models import Employee

class Employee_form(forms.ModelForm):

    class Meta:
        model=Employee
        fields = ('fullname','empCode','mobile','position')
        labels={
            'fullname':'Enter Full Name',
            'empCode':'Enter Employee Code',
            'mobile':'Enter Mobile Number',
            'position':'Select Your Position'
        }
    def __init__(self,*args,**kwargs):
        super(Employee_form,self).__init__(*args,**kwargs)
        self.fields['position'].empty_label="Select me"
        self.fields['empCode'].required= False